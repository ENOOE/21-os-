#include "types.h"
#include "riscv.h"
#include "defs.h"
#include "param.h"
#include "memlayout.h"
#include "spinlock.h"
#include "proc.h"
#include "semaphore.h" 

// 信号量表
struct semaphore semtable[NSEM];

// 初始化信号量表
void
seminit(void)
{
  for(int i = 0; i < NSEM; i++) {
    semtable[i].active = 0; // 标记为未使用
    initlock(&semtable[i].lock, "sem"); // 初始化自旋锁
  }
}

// "打开" (或创建) 一个信号量
int
sem_open(uint id, int value)
{
  // 检查参数合法性
  if(id >= NSEM || value < 0)
    return -1;

  acquire(&semtable[id].lock); // 获取该信号量的锁
  
  // 检查是否已被激活
  if(semtable[id].active) {
    release(&semtable[id].lock);
    return -1; // 已经存在，不能重复 open
  }

  // 激活并设置
  semtable[id].id = id;
  semtable[id].value = value;
  semtable[id].active = 1;
  
  release(&semtable[id].lock); // 释放锁
  return 0;
}

// "关闭" (或释放) 一个信号量
int
sem_close(uint id)
{
  // 检查参数合法性
  if(id >= NSEM || !semtable[id].active)
    return -1;

  acquire(&semtable[id].lock); // 获取锁

  semtable[id].active = 0;
  semtable[id].value = 0;

  // 关键: 唤醒所有可能在等待该信号量的进程
  wakeup(&semtable[id]); 
  
  release(&semtable[id].lock); // 释放锁
  return 0;
}

// P 操作 (sem_down / "wait")
void
sem_down(struct semaphore *s)
{
  // 必须先获取锁，才能安全地检查 value
  acquire(&s->lock);
  
  // 循环检查，直到 value > 0
  while(s->value <= 0) {
    // value 不可用，释放 s->lock 并休眠
    // 等待在 s 这个通道上
    sleep(s, &s->lock);
    // 
    // sleep 返回时，它已经重新获取了 s->lock
    // while 循环会再次检查 s->value
  }

  // 成功获取信号量
  s->value--;
  
  release(&s->lock);
}

// V 操作 (sem_up / "signal")
void
sem_up(struct semaphore *s)
{
  acquire(&s->lock);
  
  // 释放一个资源
  s->value++;
  
  // 唤醒一个在 s 通道上等待的进程
  // (hsy 报告中也是这样做的)
  wakeup(s);

  release(&s->lock);
}
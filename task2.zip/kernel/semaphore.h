#ifndef _SEMAPHORE_H_
#define _SEMAPHORE_H_

#include "spinlock.h"
#include "types.h"


struct semaphore {
  uint id;            // 唯一标识
  int value;          // 信号量当前值
  struct spinlock lock; // 保护 value 的自旋锁
  int active;         // 是否已经被 open
};

#define NSEM 32 // 最多支持 32 个信号量

// 函数声明
void seminit(void);
int  sem_open(uint id, int initial_value);
int  sem_close(uint id);
void sem_up(struct semaphore *s);
void sem_down(struct semaphore *s);

#endif // _SEMAPHORE_H_
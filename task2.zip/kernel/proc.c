/*
 * 进程管理模块（proc.c）- 基于RISC-V架构的XV6内核
 * 实现多级反馈队列（MLFQ）调度器，包含进程创建、销毁、调度、同步等核心功能
 * 核心改动：替换默认调度器为MLFQ，支持优先级动态调整、防饥饿的优先级提升机制
 */
#include "types.h"
#include "param.h"
#include "memlayout.h"
#include "riscv.h"
#include "spinlock.h"
#include "proc.h"
#include "defs.h"

// 全局变量定义 - 进程与CPU相关
struct cpu cpus[NCPU];                // 每个CPU的核心数据结构
struct proc proc[NPROC];              // 进程表，最多支持NPROC个进程
struct proc *initproc;                // 初始化进程（init）指针
int nextpid = 1;                      // 下一个可用的进程ID
struct spinlock pid_lock;             // 保护pid分配的自旋锁

// 空闲进程（idle）相关 - 每个CPU绑定一个idle进程
struct proc *idleprocs[NCPU];

// MLFQ调度器核心配置

// 各优先级队列的时间片配置（优先级越高，时间片越短）
int queue_time_slice[NMLFQ] = {1, 2, 4, 8, 16};

extern uint ticks;                    // 全局时钟滴答数
// 外部引用
extern void forkret(void);
extern char trampoline[];  // 跳板代码（trampoline.S）

// 同步锁：保证wait()的唤醒不丢失，访问parent字段时的内存模型合规
struct spinlock wait_lock;

// 函数声明
static void freeproc(struct proc *p);
void proc_mapstacks(pagetable_t kpgtbl);
struct proc* steal_from(struct cpu *c);

void procinit(void);
int cpuid(void);
struct cpu *mycpu(void);
struct proc *myproc(void);
int allocpid(void);
static struct proc *allocproc(void);
pagetable_t proc_pagetable(struct proc *p);
void proc_freepagetable(pagetable_t pagetable, uint64 sz);
void userinit(void);
int growproc(int n);
int kfork(void);
void reparent(struct proc *p);
void kexit(int status);
int kwait(uint64 addr);
void schedule(void);
void scheduler(void);
void sched(void);
void yield(void);
void forkret(void);
void sleep(void *chan, struct spinlock *lk);
void wakeup(void *chan);
int kkill(int pid);
void setkilled(struct proc *p);
int killed(struct proc *p);
int either_copyout(int user_dst, uint64 dst, void *src, uint64 len);
int either_copyin(void *dst, int user_src, uint64 src, uint64 len);
void procdump(void);


void rq_enqueue(struct cpu *c, int prio, struct proc *p);
struct proc* rq_dequeue(struct cpu *c);



/*
 * 获取当前CPU的ID
 * 要求：调用时必须关闭中断，防止进程被迁移到其他CPU
 */
int cpuid()
{
    int id = r_tp();
    return id;
}

/*
 * 获取当前CPU的cpu结构体指针
 * 要求：调用时必须关闭中断
 */
struct cpu *mycpu(void)
{
    int id = cpuid();
    struct cpu *c = &cpus[id];
    return c;
}

/*
 * 获取当前运行的进程结构体指针（无则返回0）
 */
struct proc *myproc(void)
{
    push_off();          // 关闭中断，防止进程切换
    struct cpu *c = mycpu();
    struct proc *p = c->proc;
    pop_off();           // 恢复中断
    return p;
}

/*
 * 初始化进程表和核心锁
 * 1. 初始化所有进程槽位
 * 2. 为每个CPU分配idle进程
 * 3. 初始化MLFQ调度器
 */
void procinit(void)
{
    struct proc *p;

    // 初始化PID分配锁和wait锁
    initlock(&pid_lock, "nextpid");
    initlock(&wait_lock, "wait_lock");

    // 初始化所有进程槽位的基础属性
    for(p = proc; p < &proc[NPROC]; p++)
    {
        initlock(&p->lock, "proc");
        p->state = UNUSED;
        p->kstack = KSTACK((int)(p - proc));
        p->priority = 0;
        p->ticks_in_queue = 0;
        p->entry_time = 0;
    }

    // 为每个CPU分配专用idle进程（占用前NCPU个进程槽位）
    for(int i = 0; i < NCPU; i++)
    {
        idleprocs[i] = &proc[i];
        idleprocs[i]->state = RUNNABLE;  // idle进程始终处于就绪态
        idleprocs[i]->pid = 0;           // PID=0标识idle进程
        idleprocs[i]->priority = NMLFQ - 1;  // 最低优先级

        // 设置进程名，便于调试
        safestrcpy(idleprocs[i]->name, "idle", sizeof(idleprocs[i]->name));
    }

    // 初始化MLFQ调度器
    
    for(int i = 0; i < NCPU; i++){
    initlock(&cpus[i].rq_lock, "rq");
    cpus[i].nrunnable = 0;
    for(int j = 0; j < NMLFQ; j++){
        cpus[i].rq[j].front = 0;
        cpus[i].rq[j].rear  = 0;
        cpus[i].rq[j].count = 0;
    }
}

}

/*
 * 为所有进程分配内核栈并映射到高地址空间
 * 每个内核栈后紧跟一个无效的保护页，防止栈溢出
 */
void proc_mapstacks(pagetable_t kpgtbl)
{
    struct proc *p;

    for(p = proc; p < &proc[NPROC]; p++)
    {
        char *pa = kalloc();
        if(pa == 0)
            panic("kalloc failed: no memory for kernel stack");
        
        uint64 va = KSTACK((int)(p - proc));
        // 映射内核栈：读写权限，仅内核可访问
        kvmmap(kpgtbl, va, (uint64)pa, PGSIZE, PTE_R | PTE_W);
    }
}

/*
 * 分配新的进程ID
 * 线程安全：通过pid_lock保护nextpid
 */
int allocpid()
{
    int pid;

    acquire(&pid_lock);
    pid = nextpid;
    nextpid += 1;
    release(&pid_lock);
    return pid;
}

/*
 * 分配新的进程结构体
 * 1. 从进程表中找UNUSED的槽位（跳过前NCPU个idle进程）
 * 2. 初始化进程核心属性（PID、内核栈、页表、上下文等）
 * 3. 返回时持有进程锁，失败返回0
 */
static struct proc *allocproc(void)
{
    struct proc *p;

    // 遍历进程表（跳过前NCPU个idle进程）
    for(p = &proc[NCPU]; p < &proc[NPROC]; p++)
    {
        acquire(&p->lock);
        if(p->state == UNUSED)
        {
            goto found;
        }
        else
        {
            release(&p->lock);
        }
    }

    // 无空闲进程槽位，打印调试信息
    printf("\n!!! allocproc failed: no free proc slot !!!\n");
    printf("NPROC=%d, NCPU=%d\n", NPROC, NCPU);
    
    struct proc *debug_p = &proc[NCPU];
    acquire(&debug_p->lock);
    printf("Debug proc[%d]: state=%d (0=UNUSED), pid=%d\n", 
           NCPU, debug_p->state, debug_p->pid);
    release(&debug_p->lock);

    return 0;

found:
    // 初始化进程基础属性
    p->pid = allocpid();
    p->state = USED;

    // 分配trapframe页
    p->trapframe = (struct trapframe *)kalloc();
    if(p->trapframe == 0)
    {
        printf("allocproc: kalloc trapframe failed\n");
        freeproc(p);
        release(&p->lock);
        return 0;
    }

    // 创建空的用户页表
    p->pagetable = proc_pagetable(p);
    if(p->pagetable == 0)
    {
        printf("allocproc: proc_pagetable failed\n");
        freeproc(p);
        release(&p->lock);
        return 0;
    }

    // 初始化进程上下文：从forkret开始执行
    memset(&p->context, 0, sizeof(p->context));
    p->context.ra = (uint64)forkret;
    p->context.sp = p->kstack + PGSIZE;

    // 初始化MLFQ相关属性
    p->priority = 0;          // 新进程默认最高优先级
    p->ticks_in_queue = 0;
    p->entry_time = ticks;

    return p;
}

/*
 * 释放进程结构体及关联资源
 * 要求：调用时必须持有进程锁
 * @param p: 要释放的进程指针
 */
static void freeproc(struct proc *p)
{
    // 释放trapframe
    if(p->trapframe)
    {
        kfree((void *)p->trapframe);
        p->trapframe = 0;
    }

    // 释放用户页表
    if(p->pagetable)
    {
        proc_freepagetable(p->pagetable, p->sz);
        p->pagetable = 0;
    }

    // 重置进程属性
    p->sz = 0;
    p->pid = 0;
    p->parent = 0;
    p->name[0] = 0;
    p->chan = 0;
    p->killed = 0;
    p->xstate = 0;

    // 重置MLFQ相关属性
    p->priority = 0;
    p->ticks_in_queue = 0;
    p->entry_time = 0;

    p->state = UNUSED;
}

/*
 * 创建进程的用户页表
 * 包含trampoline和trapframe的映射，无用户内存
 * @param p: 目标进程指针
 * @return: 页表指针（失败返回0）
 */
pagetable_t proc_pagetable(struct proc *p)
{
    pagetable_t pagetable = uvmcreate();
    if(pagetable == 0)
        return 0;

    // 映射trampoline代码（最高用户虚拟地址）
    if(mappages(pagetable, TRAMPOLINE, PGSIZE, 
                (uint64)trampoline, PTE_R | PTE_X) < 0)
    {
        uvmfree(pagetable, 0);
        return 0;
    }

    // 映射trapframe页（trampoline下方）
    if(mappages(pagetable, TRAPFRAME, PGSIZE, 
                (uint64)(p->trapframe), PTE_R | PTE_W) < 0)
    {
        uvmunmap(pagetable, TRAMPOLINE, 1, 0);
        uvmfree(pagetable, 0);
        return 0;
    }

    return pagetable;
}

/*
 * 释放进程的用户页表及关联物理内存
 * @param pagetable: 要释放的页表
 * @param sz: 进程用户内存大小
 */
void proc_freepagetable(pagetable_t pagetable, uint64 sz)
{
    // 解除trampoline和trapframe映射
    uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    uvmunmap(pagetable, TRAPFRAME, 1, 0);
    // 释放用户内存
    uvmfree(pagetable, sz);
}

/*
 * 初始化第一个用户进程（initproc）
 */
void userinit(void)
{
    struct proc *p = allocproc();
    initproc = p;

    // 设置当前工作目录为根目录
    p->cwd = namei("/");
    p->state = RUNNABLE;

    release(&p->lock);

    // 将第一个进程加入MLFQ队列 - 使用新的调度原语
    rq_enqueue(mycpu(), p->priority, p);
}

/*
 * 调整进程用户内存大小
 * @param n: 调整量（正：扩容，负：缩容）
 * @return: 0成功，-1失败
 */
int growproc(int n)
{
    uint64 sz;
    struct proc *p = myproc();

    sz = p->sz;
    if(n > 0)
    {
        // 扩容：分配新的内存页
        sz = uvmalloc(p->pagetable, sz, sz + n, PTE_W);
        if(sz == 0) return -1;
    }
    else if(n < 0)
    {
        // 缩容：释放内存页
        sz = uvmdealloc(p->pagetable, sz, sz + n);
    }
    p->sz = sz;
    return 0;
}

/*
 * 创建新进程（fork系统调用的内核实现）
 * 1. 分配新进程槽位
 * 2. 复制父进程的用户内存、文件描述符、目录等
 * 3. 初始化子进程上下文，加入MLFQ队列
 * @return: 子进程PID（失败返回-1）
 */
int kfork(void)
{
    int i, pid;
    struct proc *np;
    struct proc *p = myproc();

    // 分配新进程
    np = allocproc();
    if(np == 0) return -1;

    // 复制父进程用户内存
    if(uvmcopy(p->pagetable, np->pagetable, p->sz) < 0)
    {
        printf("kfork: uvmcopy failed\n");
        freeproc(np);
        release(&np->lock);
        return -1;
    }
    np->sz = p->sz;

    // 复制用户寄存器状态
    *(np->trapframe) = *(p->trapframe);
    // 让fork在子进程中返回0
    np->trapframe->a0 = 0;

    // 复制文件描述符引用
    for(i = 0; i < NOFILE; i++)
    {
        if(p->ofile[i])
            np->ofile[i] = filedup(p->ofile[i]);
    }
    // 复制当前工作目录
    np->cwd = idup(p->cwd);

    // 复制进程名
    safestrcpy(np->name, p->name, sizeof(p->name));

    // 复制MLFQ优先级属性
    np->priority = p->priority;
    np->ticks_in_queue = 0;
    np->entry_time = ticks;

    pid = np->pid;

    release(&np->lock);

    // 设置父进程关系
    acquire(&wait_lock);
    np->parent = p;
    release(&wait_lock);

    // 标记子进程为就绪态
    acquire(&np->lock);
    np->state = RUNNABLE;
    release(&np->lock);

    // 将子进程加入MLFQ队列 - 使用新的调度原语
    struct cpu *c = &cpus[p->last_cpu];
    rq_enqueue(c, np->priority, np);

    return pid;
}

/*
 * 将进程p的子进程重新父化到initproc
 * 要求：调用时必须持有wait_lock
 * @param p: 被退出的进程
 */
void reparent(struct proc *p)
{
    struct proc *pp;

    for(pp = proc; pp < &proc[NPROC]; pp++)
    {
        if(pp->parent == p)
        {
            pp->parent = initproc;
            wakeup(initproc);
        }
    }
}

/*
 * 进程退出（exit系统调用的内核实现）
 * 1. 关闭所有打开的文件
 * 2. 释放目录引用
 * 3. 从MLFQ队列移除
 * 4. 重新父化子进程，标记为ZOMBIE态
 * 5. 触发调度，永不返回
 */
void kexit(int status)
{
    struct proc *p = myproc();

    // init进程不允许退出
    if(p == initproc)
        panic("init process exiting");

    // 关闭所有打开的文件
    for(int fd = 0; fd < NOFILE; fd++)
    {
        if(p->ofile[fd])
        {
            fileclose(p->ofile[fd]);
            p->ofile[fd] = 0;
        }
    }

    // 释放当前工作目录
    begin_op();
    iput(p->cwd);
    end_op();
    p->cwd = 0;

    // 注意：mlfq_remove已被删除，进程退出时会自动从队列中移除
    // 因为进程状态变为ZOMBIE，不会被调度

    acquire(&wait_lock);

    // 重新父化子进程到initproc
    reparent(p);
    // 唤醒等待的父进程
    wakeup(p->parent);

    // 标记退出状态，转为僵尸态
    p->xstate = status;
    p->state = ZOMBIE;

    release(&wait_lock);

    // 关闭中断，准备调度
    intr_off();

    // 进入调度器，永不返回
    sched();
    panic("zombie exit: unreachable code");
}

/*
 * 等待子进程退出（wait系统调用的内核实现）
 * @param addr: 用户空间存储退出状态的地址（0则不存储）
 * @return: 退出子进程的PID（无子女返回-1）
 */
int kwait(uint64 addr)
{
    struct proc *pp;
    int havekids, pid;
    struct proc *p = myproc();

    acquire(&wait_lock);

    for(;;)
    {
        havekids = 0;
        // 遍历进程表查找子进程
        for(pp = proc; pp < &proc[NPROC]; pp++)
        {
            if(pp->parent == p)
            {
                acquire(&pp->lock);
                havekids = 1;

                // 找到僵尸态子进程
                if(pp->state == ZOMBIE)
                {
                    pid = pp->pid;
                    // 将退出状态复制到用户空间
                    if(addr != 0 && copyout(p->pagetable, addr, 
                                            (char *)&pp->xstate, sizeof(pp->xstate)) < 0)
                    {
                        release(&pp->lock);
                        release(&wait_lock);
                        return -1;
                    }
                    // 释放子进程资源
                    freeproc(pp);
                    release(&pp->lock);
                    release(&wait_lock);
                    return pid;
                }
                release(&pp->lock);
            }
        }

        // 无子女或当前进程被杀死，返回失败
        if(!havekids || killed(p))
        {
            release(&wait_lock);
            return -1;
        }

        // 睡眠等待子进程退出
        sleep(p, &wait_lock);
    }
}

/*
 * 核心调度函数：选择下一个要运行的进程并切换上下文
 * 1. 处理当前进程（放回队列）
 * 2. 从MLFQ队列选择最高优先级进程
 * 3. 无进程则切换到idle进程
 * 4. 执行上下文切换
 */
void schedule(void)
{
    struct proc *prev = myproc();
    struct proc *next = 0;

    // 关闭中断，保证调度原子性
    push_off();

    // 处理当前进程：若为RUNNING态，转为RUNNABLE并放回队列
    if(prev && prev->state == RUNNING)
    {
        prev->state = RUNNABLE;
        // idle进程不加入队列
        if(prev->pid != 0)
        {
            // 使用新的调度原语
            rq_enqueue(mycpu(), prev->priority, prev);
        }
    }

    // 从最高优先级开始查找就绪进程
    for(int prio = 0; prio < NMLFQ; prio++)
    {
        struct cpu *c = mycpu();
        next = rq_dequeue(c);
       
      if(!next){
      for(int i = 0; i < NCPU; i++){
        if(i == cpuid()) continue;
        next = steal_from(&cpus[i]);
        if(next) break;
    }
}
        if(next != 0 && next->state == RUNNABLE)
        {
            goto found;
        }
        next = 0; // 非就绪态，跳过
    }
found:
    // 无就绪进程，切换到当前CPU的idle进程
    if(next == 0)
    {
        int id = cpuid();
        next = idleprocs[id];
        if(next->state != RUNNABLE)
        {
            next->state = RUNNABLE;
        }
    }
    // 更新下一个进程状态，执行切换
    next->last_cpu = cpuid();
    next->state = RUNNING;mycpu()->proc = next;
    
    // 上下文切换（仅当进程不同时）
    if(prev != next)
    {
        swtch(&prev->context, &next->context);
    }

    // 切换回来后，恢复当前进程指针
    mycpu()->proc = prev;

    // 恢复中断
    pop_off();
}

/*
 * 调度器主循环（每个CPU独立运行）
 * 1. 绑定当前CPU的idle进程
 * 2. 开启中断，等待时钟中断
 * 3. 循环调用schedule进行调度
 */
void scheduler(void)
{
    struct cpu *c = mycpu();
    int id = cpuid();

    // 初始化为当前CPU的idle进程
    c->proc = idleprocs[id];

    for(;;)
    {
        // 开启中断，接收时钟唤醒
        intr_on();

        // 低功耗等待中断（WFI指令）
        asm volatile("wfi");

        // 执行调度
        schedule();
    }
}

/*
 * 触发调度的封装函数
 * 检查基本状态，调用schedule
 */
void sched(void)
{
    int intena;
    struct proc *p = myproc();

    // 状态检查（兼容原有逻辑）
    if(!holding(&p->lock) && p->state == SLEEPING)
    {
        // sleep中释放锁是合法的
    }

    if(mycpu()->noff != 1)
    {
        // 暂时注释锁检查，避免调试问题
        // panic("sched: invalid lock count");
    }

    if(p->state == RUNNING)
        panic("sched: process in running state");
    if(intr_get())
        panic("sched: interrupt enabled");

    // 保存中断使能状态
    intena = mycpu()->intena;

    // 执行调度
    schedule();

    // 恢复中断使能状态
    mycpu()->intena = intena;
}

/*
 * 主动放弃CPU（yield系统调用的内核实现）
 * 将当前进程标记为RUNNING，触发调度
 */
void yield(void)
{
    struct proc *p = myproc();
    p->state = RUNNING;
    schedule();
}

/*
 * fork子进程的第一个调度入口
 * 1. 初始化文件系统
 * 2. 执行init程序
 * 3. 返回到用户空间
 */
void forkret(void)
{
    extern char userret[];
    static int first = 1;
    struct proc *p = myproc();

    // 平衡schedule中的push_off
    pop_off();

    if(first)
    {
        // 初始化文件系统（必须在进程上下文中执行）
        fsinit(ROOTDEV);
        first = 0;
        __sync_synchronize(); // 保证其他核可见

        // 执行init程序
        p->trapframe->a0 = kexec("/init", (char *[]) {"/init", 0});
        if(p->trapframe->a0 == -1)
        {
            panic("exec failed: init process");
        }
    }

    // 返回到用户空间
    prepare_return();
    uint64 satp = MAKE_SATP(p->pagetable);
    uint64 trampoline_userret = TRAMPOLINE + (userret - trampoline);
    ((void (*)(uint64))trampoline_userret)(satp);
}

/*
 * 进程睡眠（等待某个事件）
 * @param chan: 等待通道（事件标识）
 * @param lk: 条件锁（会先释放，唤醒后重新获取）
 */
void sleep(void *chan, struct spinlock *lk)
{
    struct proc *p = myproc();

    // 释放条件锁（避免死锁）
    if(lk != &p->lock)
    {
        release(lk);
    }

    // 标记为睡眠态，设置等待通道
    p->chan = chan;
    p->state = SLEEPING;

    // 触发调度
    schedule();

    // 唤醒后清理等待通道
    p->chan = 0;

    // 重新获取条件锁
    if(lk != &p->lock)
    {
        acquire(lk);
    }
}

/*
 * 唤醒等待在指定通道的所有进程
 * @param chan: 等待通道
 * 注意：调用者需持有条件锁
 */
void wakeup(void *chan)
{
    struct proc *p;

    for(p = proc; p < &proc[NPROC]; p++)
    {
        if(p != myproc() && p->pid != 0)
        {
            acquire(&p->lock);
            if(p->state == SLEEPING && p->chan == chan)
            {
                p->state = RUNNABLE;
                release(&p->lock);

                // I/O唤醒提升为最高优先级
                p->priority = 0;
                p->ticks_in_queue = 0;
                
                // 使用新的调度原语
                struct cpu *c = &cpus[p->last_cpu];
                rq_enqueue(c, 0, p);

                continue;
            }
            release(&p->lock);
        }
    }
}

/*
 * 杀死指定PID的进程
 * @param pid: 目标进程PID
 * @return: 0成功，-1失败
 */
int kkill(int pid)
{
    struct proc *p;

    for(p = proc; p < &proc[NPROC]; p++)
    {
        acquire(&p->lock);
        if(p->pid == pid)
        {
            p->killed = 1;
            // 若进程在睡眠，唤醒它
            if(p->state == SLEEPING)
            {
                p->state = RUNNABLE;
                release(&p->lock);
                // 使用新的调度原语
                struct cpu *c = &cpus[p->last_cpu];
                rq_enqueue(c, p->priority, p);
                return 0;
            }
            release(&p->lock);
            return 0;
        }
        release(&p->lock);
    }
    return -1;
}

/*
 * 标记进程为被杀死状态
 * @param p: 目标进程指针
 */
void setkilled(struct proc *p)
{
    acquire(&p->lock);
    p->killed = 1;
    release(&p->lock);
}

/*
 * 检查进程是否被标记为杀死
 * @param p: 目标进程指针
 * @return: 1被杀死，0未被杀死
 */
int killed(struct proc *p)
{
    int k;
    acquire(&p->lock);
    k = p->killed;
    release(&p->lock);
    return k;
}

/*
 * 数据拷贝到用户/内核地址空间
 * @param user_dst: 1=用户地址，0=内核地址
 * @param dst: 目标地址
 * @param src: 源地址
 * @param len: 拷贝长度
 * @return: 0成功，-1失败
 */
int either_copyout(int user_dst, uint64 dst, void *src, uint64 len)
{
    struct proc *p = myproc();
    if(user_dst)
    {
        return copyout(p->pagetable, dst, src, len);
    }
    else
    {
        memmove((char *)dst, src, len);
        return 0;
    }
}

/*
 * 从用户/内核地址空间拷贝数据
 * @param dst: 目标地址
 * @param user_src: 1=用户地址，0=内核地址
 * @param src: 源地址
 * @param len: 拷贝长度
 * @return: 0成功，-1失败
 */
int either_copyin(void *dst, int user_src, uint64 src, uint64 len)
{
    struct proc *p = myproc();
    if(user_src)
    {
        return copyin(p->pagetable, dst, src, len);
    }
    else
    {
        memmove(dst, (char *)src, len);
        return 0;
    }
}

/*
 * 打印进程列表（调试用）
 * 当用户在控制台按^P时触发
 */
void procdump(void)
{
    static char *states[] = {
        [UNUSED]   "unused",
        [USED]     "used",
        [SLEEPING] "sleep ",
        [RUNNABLE] "runble",
        [RUNNING]  "run   ",
        [ZOMBIE]   "zombie"
    };
    struct proc *p;
    char *state;

    printf("\n=== Process List (PID | State | Name | Priority | Ticks) ===\n");
    for(p = proc; p < &proc[NPROC]; p++)
    {
        if(p->state == UNUSED)
            continue;
        
        // 确定进程状态字符串
        if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
        {
            state = states[p->state];
        }
        else
        {
            state = "???";
        }

        // 打印进程信息（含MLFQ调度相关字段）
        printf("%d\t%s\t%s\t%d\t%d\n", 
               p->pid, state, p->name, p->priority, p->ticks_in_queue);
    }
    printf("===========================================================\n");
}

void
rq_enqueue(struct cpu *c, int prio, struct proc *p)
{
    if(prio < 0) prio = 0;
    if(prio >= NMLFQ) prio = NMLFQ - 1;

    acquire(&c->rq_lock);
    if(p->state != RUNNABLE){
        release(&c->rq_lock);
        return;
    }

    struct mlfq_queue *q = &c->rq[prio];
    q->procs[q->rear] = p;
    q->rear = (q->rear + 1) % NPROC;
    q->count++;

    p->priority = prio;
    p->ticks_in_queue = 0;
    c->nrunnable++;

    release(&c->rq_lock);
}
struct proc*
rq_dequeue(struct cpu *c)
{
    acquire(&c->rq_lock);
    for(int prio = 0; prio < NMLFQ; prio++){
        struct mlfq_queue *q = &c->rq[prio];
        if(q->count > 0){
            struct proc *p = q->procs[q->front];
            q->front = (q->front + 1) % NPROC;
            q->count--;
            c->nrunnable--;
            release(&c->rq_lock);
            return p;
        }
    }
    release(&c->rq_lock);
    return 0;
}


void
age_boost_cpu(struct cpu *c)
{
    acquire(&c->rq_lock);
    // 从低优先级队列向高优先级队列提升
    for(int prio = 1; prio < NMLFQ; prio++) {
        struct mlfq_queue *q = &c->rq[prio];
        struct mlfq_queue *top = &c->rq[0];
        while(q->count > 0) {
            // 取出低优先级队列队头
            struct proc *p = q->procs[q->front];
            q->front = (q->front + 1) % NPROC;
            q->count--;

            // 重置调度属性
            p->priority = 0;
            p->ticks_in_queue = 0;
            p->entry_time = ticks;

            // 放入最高优先级队列尾部
            top->procs[top->rear] = p;
            top->rear = (top->rear + 1) % NPROC;
            top->count++;
        }
    }
    release(&c->rq_lock);
}

struct proc*
steal_from(struct cpu *src)
{
    acquire(&src->rq_lock);

    // 从最低优先级开始偷（prio 大 = 优先级低）
    for(int prio = NMLFQ - 1; prio >= 0; prio--) {
        struct mlfq_queue *q = &src->rq[prio];
        if(q->count > 0) {
            struct proc *p = q->procs[q->front];
            q->front = (q->front + 1) % NPROC;
            q->count--;
            src->nrunnable--;

            release(&src->rq_lock);

            // 更新 CPU 归属
            p->last_cpu = cpuid();
            return p;
        }
    }

    release(&src->rq_lock);
    return 0;
}

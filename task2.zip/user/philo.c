#include "kernel/types.h"
#include "user/user.h"

// 定义哲学家数量
#define N 5 

// 信号量 ID
#define FORK_SEM_START 10 // 叉子信号量从 ID 10 开始
#define OUTPUT_SEM 20     // 输出同步信号量

// 哲学家状态
#define THINKING 0
#define HUNGRY 1
#define EATING 2

int state[N];
int philosophers[N];

// 同步输出函数
void sync_printf(const char *fmt, int arg1, int arg2, int arg3) {
  sem_down(OUTPUT_SEM);
  if (arg3 >= 0) {
    printf(fmt, arg1, arg2, arg3);
  } else if (arg2 >= 0) {
    printf(fmt, arg1, arg2);
  } else {
    printf(fmt, arg1);
  }
  sem_up(OUTPUT_SEM);
}

// 简单的延时函数替代sleep
void delay(int ticks) {
  for (volatile int i = 0; i < ticks * 100000; i++) {
    // 忙等待
  }
}

void think(int id) {
  sync_printf("Philosopher %d is THINKING.\n", id, -1, -1);
  delay(10); // 思考一会儿
}

void eat(int id) {
  sync_printf("Philosopher %d is EATING.\n", id, -1, -1);
  delay(5); // 进餐一会儿
}

// 尝试获取两把叉子
void acquire_forks(int id) {
  int left_fork = FORK_SEM_START + id;
  int right_fork = FORK_SEM_START + (id + 1) % N;

  if (id % 2 == 0) {
    // 偶数哲学家：先拿右叉
    sync_printf("Philosopher %d is HUNGRY, trying right fork %d...\n", id, right_fork, -1);
    sem_down(right_fork);
    
    sync_printf("Philosopher %d got right fork %d, trying left fork %d...\n", id, right_fork, left_fork);
    sem_down(left_fork);
  } else {
    // 奇数哲学家：先拿左叉
    sync_printf("Philosopher %d is HUNGRY, trying left fork %d...\n", id, left_fork, -1);
    sem_down(left_fork);

    sync_printf("Philosopher %d got left fork %d, trying right fork %d...\n", id, left_fork, right_fork);
    sem_down(right_fork);
  }
}

// 释放两把叉子
void release_forks(int id) {
  int left_fork = FORK_SEM_START + id;
  int right_fork = FORK_SEM_START + (id + 1) % N;

  sem_up(left_fork);
  sem_up(right_fork);
  sync_printf("Philosopher %d released forks %d and %d.\n", id, left_fork, right_fork);
}

void philosopher(int id) {
  for (int i = 0; i < 3; i++) { // 每位哲学家吃 3 轮
    state[id] = THINKING;
    think(id);

    state[id] = HUNGRY;
    acquire_forks(id);

    state[id] = EATING;
    eat(id);

    release_forks(id);
  }
  sync_printf("Philosopher %d finished dining.\n", id, -1, -1);
  exit(0);
}

int
main(int argc, char *argv[])
{
  // 1. 初始化输出同步信号量
  if (sem_open(OUTPUT_SEM, 1) < 0) {
    fprintf(2, "philo: failed to open output semaphore\n");
    exit(1);
  }

  // 2. 初始化所有叉子信号量 (N 把叉子，初始值都为 1)
  for (int i = 0; i < N; i++) {
    int id = FORK_SEM_START + i;
    if (sem_open(id, 1) < 0) {
      fprintf(2, "philo: failed to open semaphore %d\n", id);
      exit(1);
    }
  }

  printf("Dining Philosophers Problem Simulation (N=%d)\n", N);
  printf("----------------------------------------\n");

  // 3. 启动 N 个哲学家进程
  for (int i = 0; i < N; i++) {
    if (fork() == 0) {
      philosopher(i);
    }
  }

  // 4. 等待所有哲学家进程结束
  for (int i = 0; i < N; i++) {
    wait(0);
  }

  // 5. 关闭所有信号量
  for (int i = 0; i < N; i++) {
    sem_close(FORK_SEM_START + i);
  }
  sem_close(OUTPUT_SEM);

  printf("----------------------------------------\n");
  printf("philo: All philosophers finished dining successfully.\n");
  exit(0);
}
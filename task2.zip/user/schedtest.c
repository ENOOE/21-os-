#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

/*
 * ========= 参数 =========
 */
#define CPU_SPIN   200000000
#define IO_ROUNDS  20
#define IO_DELAY   1000000
#define START_TICK 50

/*
 * 等待系统 tick 对齐，确保所有进程几乎同时开始
 */
static void
sync_start(void)
{
    while (uptime() < START_TICK)
        ;
}

/*
 * ========================
 * CPU-bound 任务
 * 特点：
 *   - 永不 sleep
 *   - 不主动 yield
 *   - 只能被 timer 中断抢占
 * ========================
 */
void
cpu_task(char tag)
{
    volatile int x = 0;
    sync_start();

    int start = uptime();
    printf("[CPU-%c] pid=%d START tick=%d\n",
           tag, getpid(), start);

    for (;;) {
        for (int i = 0; i < CPU_SPIN; i++) {
            x++;
        }

        printf("[CPU-%c] pid=%d ALIVE tick=%d\n",
               tag, getpid(), uptime());
    }
}

/*
 * ========================
 * IO-bound 任务
 * 特点：
 *   - 父进程 read → SLEEPING
 *   - 子进程 write → wakeup
 *   - wakeup 后 priority=0
 * ========================
 */
void
io_task(char tag)
{
    int fd[2];
    char buf;

    pipe(fd);
    sync_start();

    int start = uptime();
    printf("[IO-%c ] pid=%d START tick=%d\n",
           tag, getpid(), start);

    for (int i = 0; i < IO_ROUNDS; i++) {

        if (fork() == 0) {
            // 子进程：模拟短暂计算 + I/O 完成
            volatile int j;
            for (j = 0; j < IO_DELAY; j++)
                ;
            write(fd[1], "x", 1);
            exit(0);
        }

        // 父进程：阻塞 read
        read(fd[0], &buf, 1);

        printf("[IO-%c ] pid=%d WAKE #%d tick=%d\n",
               tag, getpid(), i, uptime());
    }

    printf("[IO-%c ] pid=%d EXIT tick=%d\n",
           tag, getpid(), uptime());
    exit(0);
}

/*
 * ========================
 * 主程序
 * ========================
 */
int
main(int argc, char *argv[])
{
    printf("\n");
    printf("============================================\n");
    printf("   MLFQ + PER-CPU RUNQUEUE MULTI-CPU TEST\n");
    printf("============================================\n");
    printf(" - CPU-bound tasks: A, B\n");
    printf(" - IO-bound  task : C\n");
    printf(" - START_TICK     : %d\n", START_TICK);
    printf("\n");
    printf(">>> 观察要点：\n");
    printf(">>> 1. CPU-A 与 CPU-B 的 ALIVE tick 是否高度重叠\n");
    printf(">>> 2. IO-C wakeup 后是否迅速打印（priority boost）\n");
    printf(">>> 3. Ctrl+P 查看 priority / ticks\n");
    printf("\n");

    if (fork() == 0)
        cpu_task('A');

    if (fork() == 0)
        cpu_task('B');

    if (fork() == 0)
        io_task('C');

    // 父进程：保持系统存活
    for (;;) {
        wait(0);
    }
}

